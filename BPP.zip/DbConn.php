<?php
    $conn = new mysqli("localhost", "root", "ladd2carew", "BallparkPicks");
?>
